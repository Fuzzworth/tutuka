package com.tutuka.project.Tutuka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutukaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutukaApplication.class, args);
	}

}

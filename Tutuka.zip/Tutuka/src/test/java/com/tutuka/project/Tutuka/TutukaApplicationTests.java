package com.tutuka.project.Tutuka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutukaApplicationTests {

	@Test
	void contextLoads() {
	}

}
